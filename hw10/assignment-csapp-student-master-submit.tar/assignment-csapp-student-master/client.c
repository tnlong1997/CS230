#include  "csapp.h"

int MUL(int x, int y) {
    return x*y;
}

int main(){
  int clientfd = open_clientfd("elnux1.cs.umass.edu",5250);
  if(clientfd < 0){
    printf("%s\n", "connection error");
  }
  else{
    printf("%s\n","Connected to server.");

    FILE* file = Fdopen(clientfd,"a+");

    // Spire ID to server
    printf("%s\n", "Sending Spire ID " );
    fprintf(file, "29810842");

    //get question
    char* line = NULL;
    int count;
    getline(&line,&count,file);

    //print out question: the question is MUL
    printf("%s", "Received problem: ");
    printf("%s\n", line);

    //get str and idx
    int str;
    int idx;
    count= sscanf(line, "MUL%d%d", &str, &idx);
    if(count == EOF){
      printf("%s\n", "sscanf error");
    }
    
    int result = MUL(str,idx);
    
    //Init
    free(line);
    line = NULL;

    //write the answer to server
    printf("Sending solution: %d\n", result);
    fprintf(file, "%d\n", result);

    //receive msg from server, get line again
    getline(&line,&count,file);

    //print msg
    printf("%s\n", line);

    //init
    free(line);
    line=NULL;

    //bonus to server
    fprintf(file,"%s\n", "42");

    //get bonus result
    getline(&line,&count,file);
    printf("%s\n", line);

    //Reinit
    free(line);
    line = NULL;

    //close
    Fclose(file);
    close(clientfd);
    printf("%s\n", "Disconnect from server.");
  }

}